package com.demo.spschool.webview;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/** WebView prototype for the public S.P. School website; no injected JavaScript bridge. */
public final class MainActivity extends Activity {
    private static final String BASE_URL = "https://sp-school-v5.vercel.app/";
    private static final String HOME_URL = BASE_URL + "#hub";
    private static final int FILE_CHOOSER_REQUEST = 101;

    private WebView webView;
    private ProgressBar loadingBar;
    private LinearLayout errorPane;
    private ValueCallback<Uri[]> pendingUpload;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(22, 52, 91));
        buildScreen();
        configureWebView();
        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(HOME_URL);
        }
    }

    private void buildScreen() {
        LinearLayout app = new LinearLayout(this);
        app.setOrientation(LinearLayout.VERTICAL);
        app.setBackgroundColor(Color.WHITE);
        setContentView(app);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(10), dp(12), dp(10));
        top.setBackgroundColor(Color.rgb(28, 70, 119));
        app.addView(top, new LinearLayout.LayoutParams(-1, dp(64)));

        LinearLayout nameColumn = new LinearLayout(this);
        nameColumn.setOrientation(LinearLayout.VERTICAL);
        top.addView(nameColumn, new LinearLayout.LayoutParams(0, -2, 1));
        TextView title = text("S.P. SCHOOL", 19, Color.WHITE, true);
        nameColumn.addView(title);
        TextView subTitle = text("SUTA Digital Platform · WebView", 11, Color.rgb(209, 233, 249), false);
        nameColumn.addView(subTitle);

        TextView home = topButton("⌂", "กลับหน้าแรก");
        home.setOnClickListener(v -> { hideError(); webView.loadUrl(HOME_URL); });
        top.addView(home);
        TextView reload = topButton("↻", "โหลดใหม่");
        reload.setOnClickListener(v -> { hideError(); webView.reload(); });
        top.addView(reload);
        TextView external = topButton("↗", "เปิดในเบราว์เซอร์");
        external.setOnClickListener(v -> openExternal(Uri.parse(BASE_URL)));
        top.addView(external);

        loadingBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingBar.setMax(100);
        loadingBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(232, 117, 172)));
        loadingBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(224, 233, 243)));
        app.addView(loadingBar, new LinearLayout.LayoutParams(-1, dp(3)));

        FrameLayout page = new FrameLayout(this);
        app.addView(page, new LinearLayout.LayoutParams(-1, 0, 1));
        webView = new WebView(this);
        page.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        errorPane = new LinearLayout(this);
        errorPane.setOrientation(LinearLayout.VERTICAL);
        errorPane.setGravity(Gravity.CENTER);
        errorPane.setPadding(dp(24), dp(20), dp(24), dp(20));
        errorPane.setBackgroundColor(Color.rgb(246, 248, 252));
        page.addView(errorPane, new FrameLayout.LayoutParams(-1, -1));
        errorPane.addView(text("เชื่อมต่อเว็บไซต์ไม่ได้", 23, Color.rgb(28, 57, 98), true));
        TextView help = text("ตรวจสอบอินเทอร์เน็ตแล้วแตะ ‘ลองอีกครั้ง’ หรือเปิดเว็บไซต์ในเบราว์เซอร์", 15, Color.rgb(95, 108, 128), false);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(14), 0, dp(20));
        errorPane.addView(help);
        TextView tryAgain = text("  ลองอีกครั้ง  ", 16, Color.WHITE, true);
        tryAgain.setGravity(Gravity.CENTER);
        tryAgain.setBackgroundColor(Color.rgb(39, 107, 168));
        tryAgain.setPadding(dp(16), dp(12), dp(16), dp(12));
        tryAgain.setOnClickListener(v -> { hideError(); webView.loadUrl(HOME_URL); });
        errorPane.addView(tryAgain);
        errorPane.setVisibility(View.GONE);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);  // The public site is a JavaScript app.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Needed for Android's file chooser.
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return handleNavigation(request.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(Uri.parse(url));
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                hideError();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) showError();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loadingBar.setProgress(progress);
                loadingBar.setVisibility(progress == 100 ? View.INVISIBLE : View.VISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> filePathCallback, FileChooserParams chooserParams) {
                if (pendingUpload != null) pendingUpload.onReceiveValue(null);
                pendingUpload = filePathCallback;
                try {
                    Intent intent = chooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    pendingUpload = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "ไม่พบแอปสำหรับเลือกไฟล์", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
    }

    private boolean handleNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme();
        if ("https".equalsIgnoreCase(scheme) && "sp-school-v5.vercel.app".equalsIgnoreCase(uri.getHost())) {
            return false; // Keep same-host navigation in WebView.
        }
        openExternal(uri); // All other hosts and special schemes leave WebView.
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (Exception ex) {
            Toast.makeText(this, "ไม่พบแอปสำหรับเปิดลิงก์นี้", Toast.LENGTH_SHORT).show();
        }
    }

    private void showError() {
        errorPane.setVisibility(View.VISIBLE);
        webView.setVisibility(View.INVISIBLE);
        loadingBar.setVisibility(View.INVISIBLE);
    }
    private void hideError() {
        errorPane.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && pendingUpload != null) {
            pendingUpload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pendingUpload = null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override public void onBackPressed() {
        if (errorPane.getVisibility() == View.VISIBLE) {
            hideError();
            webView.loadUrl(HOME_URL);
        } else if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
    @Override protected void onDestroy() {
        if (pendingUpload != null) { pendingUpload.onReceiveValue(null); pendingUpload = null; }
        if (webView != null) {
            ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
        }
        super.onDestroy();
    }
    private TextView topButton(String label, String description) {
        TextView button = text(label, 25, Color.WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setContentDescription(description);
        button.setPadding(dp(6), dp(4), dp(6), dp(4));
        button.setMinWidth(dp(43));
        button.setMinHeight(dp(43));
        return button;
    }
    private TextView text(String content, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(content);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
}
