# Downloads the official Gradle distribution once; independent of wrapper JAR.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$base = Join-Path $env:USERPROFILE '.gradle\spschool-bootstrap'
$zip = Join-Path $base 'gradle-8.9-bin.zip'
$gradle = Join-Path $base 'gradle-8.9\bin\gradle.bat'
if (!(Test-Path $gradle)) {
    New-Item -ItemType Directory -Force -Path $base | Out-Null
    if (!(Test-Path $zip)) {
        Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip
    }
    Expand-Archive -Path $zip -DestinationPath $base -Force
}
Push-Location $root
try { & $gradle @args; exit $LASTEXITCODE }
finally { Pop-Location }
