# S.P. School — ต้นแบบ Android 2 รูปแบบ

โค้ดตัวอย่างแอป Android สำหรับโรงเรียนสุตะบำรุงพิทยาคาร (S.P. School)
อ้างอิงข้อมูลสาธารณะจาก https://sp-school-v5.vercel.app/
ตรวจสอบเนื้อหาบนเว็บเมื่อวันที่ 21 พฤศจิกายน 2569

> **ต้นแบบเพื่อพัฒนา/เปรียบเทียบ ไม่ใช่แอปทางการของโรงเรียน**
> ยังไม่เชื่อมต่อฐานข้อมูล SchoolBright, บัญชีผู้ใช้, ระบบ CRM หรือ Suta AI
> ไฟล์ ZIP นี้เป็น **source project สำหรับ Android Studio** ไม่ใช่ APK ที่สร้างเสร็จแล้ว

## โปรเจกต์

1. `01_SP_School_WebView/` — แอป Android WebView เข้าถึงเว็บไซต์ออนไลน์ทันที
   - เปิด `https://sp-school-v5.vercel.app/#hub`
   - มีหน้า Home, Reload, เปิดเบราว์เซอร์ และข้อความแสดงเมื่อเว็บโหลดไม่ได้
   - รองรับ JavaScript, local storage ของเว็บไซต์, และตัวเลือกอัปโหลดไฟล์
   - ลิงก์ออกนอกโดเมนโรงเรียนส่งไปยังเบราว์เซอร์หรือแอปภายนอก
   - ต้องใช้อินเทอร์เน็ตและเว็บยังต้องทำงานอยู่

2. `02_SP_School_Native/` — แอป Android แบบหน้าจอ Native แยกจากเว็บ
   - หน้าแรก/แนะนำโรงเรียน; โปรแกรม IP, MEP, REG และมัธยมต้น
   - ค่าเทอมอ้างอิงระเบียบการ **ปีการศึกษา 2569** (แสดงออฟไลน์)
   - School Matching **สาธิต 5 ข้อ** พร้อมผล, คัดลอก/แชร์
   - รายการโปรแกรมที่สนใจ (บันทึกแค่รหัสโปรแกรมในเครื่อง)
   - ปฏิทินสำหรับผู้ปกครอง คำถามพื้นฐาน และโทรติดต่อโรงเรียน
   - ลิงก์เปิดเว็บไซต์จริงเพื่อตรวจสอบข้อมูลล่าสุด

## เปิดและสร้าง APK ด้วย Android Studio

ต้องมี Android Studio รุ่นที่รองรับ Android Gradle Plugin 8.7.3, JDK 17+, Android SDK Platform 35 และอินเทอร์เน็ตเพื่อให้ Gradle ดาวน์โหลดปลั๊กอิน

1. แตก ZIP นี้
2. เพราะไม่ได้แนบ Gradle Wrapper JAR ทางการ ให้เปิด Terminal ในโฟลเดอร์โปรเจกต์ที่จะใช้ แล้วรัน `./gradlew wrapper --gradle-version 8.9` (macOS/Linux) หรือ `gradlew.bat wrapper --gradle-version 8.9` (Windows) **ครั้งแรก** เพื่อดาวน์โหลด Gradle และสร้าง Wrapper ทางการ
3. เปิด **Android Studio → File → Open** แล้วเลือกโฟลเดอร์ `01_SP_School_WebView` (หรือ `02_SP_School_Native`)
4. รอ **Gradle Sync** ให้สำเร็จ; ถ้ามีคำถาม ให้ติดตั้ง Android SDK 35 และตั้ง Gradle JDK เป็น JDK 17 หรือ 21
5. เลือกอุปกรณ์ Android หรือ Emulator แล้วกด ▶ Run เพื่อทดสอบ
6. สร้าง APK ผ่าน **Build → Build Bundle(s) / APK(s) → Build APK(s)**
7. ไฟล์ APK debug ปกติจะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk` ภายในโปรเจกต์ที่เปิด

สร้าง APK ผ่าน Terminal ในแต่ละโฟลเดอร์:

```bash
# macOS/Linux
./gradlew assembleDebug
```

```powershell
# Windows
.\gradlew.bat assembleDebug
```

**หมายเหตุเกี่ยวกับ Gradle:** เนื่องจากสภาพแวดล้อมจัดทำไฟล์ไม่มี Gradle SDK และดาวน์โหลดไบนารีเพื่อแพ็กไม่ได้ โปรเจกต์จึงแนบ `gradlew` / `gradlew.bat` แบบ *bootstrap* ที่ดาวน์โหลด Gradle 8.9 จากเว็บไซต์ทางการ (`services.gradle.org`) เมื่อเรียกครั้งแรก โดยไม่ได้แนบ Gradle Wrapper JAR อย่างเป็นทางการ หาก Android Studio แจ้งว่าไม่พบ Wrapper ให้เลือกใช้ Gradle 8.9 ที่ติดตั้งไว้ หรือเปิด Terminal เรียกสคริปต์ที่แนบ (ต้องเชื่อมอินเทอร์เน็ต) ก่อนแล้วค่อย Sync.

## เปรียบเทียบ

| เกณฑ์ | WebView | Native |
|---|---|---|
| นำเว็บที่มีอยู่มาใช้งาน | ใช่ | ใช้ข้อมูลบางส่วนเป็น snapshot |
| อัปเดตเนื้อหาเมื่อเว็บเปลี่ยน | โดยอัตโนมัติ | ไม่อัตโนมัติ ต้องปรับโค้ด/API |
| ทำงานไม่มีเน็ต | ไม่รองรับเป็นหลัก | อ่านข้อมูลและทำแบบทดสอบสาธิตได้ |
| สมัครสมาชิก/SchoolBright/Suta AI | ตามสิ่งที่เว็บรองรับ | ยังไม่ได้เชื่อมจริง |
| ความยืดหยุ่นของ UI | ต่ำกว่า | สูงกว่า |
| เหมาะกับ | ทดสอบ/ใช้งานเว็บเร็ว | พัฒนาระยะยาว |

## จุดที่แก้ไขได้

- WebView URL: `01_SP_School_WebView/app/src/main/java/com/demo/spschool/webview/MainActivity.java` → `BASE_URL`
- Native ข้อมูลโรงเรียน/ค่าเทอม/โปรแกรม/เบอร์โทร: `02_SP_School_Native/app/src/main/java/com/demo/spschool/nativeapp/SchoolData.java`
- Native หน้าจอ/ปุ่ม/แบบประเมิน: `02_SP_School_Native/app/src/main/java/com/demo/spschool/nativeapp/MainActivity.java`
- ชื่อแอป: `app/src/main/res/values/strings.xml` ของแต่ละโปรเจกต์
- ชื่อ package/app id: `app/build.gradle` และ source path (หากเปลี่ยนต้องแก้ package declarations ด้วย)
- ไอคอนต้นแบบ: `app/src/main/res/drawable/ic_school.xml`

## ขอบเขตและความเป็นส่วนตัว

- WebView ใช้เว็บไซต์จริงและส่งข้อมูลผ่านเว็บไซต์นั้น การสมัคร/ส่งฟอร์มขึ้นอยู่กับเว็บและระบบปลายทาง
- Native **ไม่มีฟอร์มเก็บชื่อ/เบอร์นักเรียนหรือผู้ปกครอง**, ไม่เชื่อมบัญชี/ฐานข้อมูล และไม่มีระบบแจ้งเตือน
- Favorite เก็บเพียงค่า boolean ต่อรหัสโปรแกรมใน `SharedPreferences` ภายในเครื่อง
- Native Quiz เป็นชุดคำถามใหม่ 5 ข้อสำหรับสาธิต UI ไม่ใช่คำถาม 10 ข้อ/ผลลัพธ์ทางการของโรงเรียน
- ค่าเทอมและปฏิทินเป็น snapshot จากหน้าเว็บ ณ วันที่ระบุ อาจเปลี่ยนตามประกาศโรงเรียน
- ก่อนเผยแพร่สู่สาธารณะ ให้ขออนุญาตใช้ชื่อ/ข้อมูล/ตราสัญลักษณ์จากเจ้าของที่เกี่ยวข้อง และตรวจสอบข้อกำหนดเว็บไซต์
- โปรเจกต์นี้ใช้สัญลักษณ์หมวกบัณฑิตที่วาดขึ้นใหม่ ไม่ใช้โลโก้ทางการและไม่คัดลอกซอร์สเว็บไซต์

## สถานะการทดสอบในสภาพแวดล้อมจัดทำ

- ตรวจสอบหน้า HTML ของแหล่งข้อมูลและเลือกข้อมูลหลักที่นำมาแสดง
- ตรวจสอบโครงสร้างไฟล์, XML, Java syntax และรายการ ZIP (ดู `CHECK_REPORT.txt`)
- **ยังไม่สามารถคอมไพล์เป็น APK หรือรันทดสอบบน Emulator ได้** เพราะเครื่องจัดทำนี้ไม่มี Android SDK/Gradle/Emulator และเข้าถึง Gradle distribution ทางเครือข่ายไม่ได้
- ควรทดสอบจริงหลัง Gradle Sync บน Android Studio ก่อนเผยแพร่

## ตัวเลือกสร้าง APK ผ่าน GitHub Actions

ใน ZIP รวมมี `.github/workflows/build-apks.yml` ซึ่งกำหนดให้ GitHub Actions สร้าง **APK debug สองตัว** เป็น artifacts เมื่อ Push โค้ดทั้งโฟลเดอร์ไปยัง GitHub repository ของคุณแล้ว เรียก Run workflow ได้จากแท็บ Actions (ใช้ได้เมื่อเปิดใช้ GitHub Actions และมีสิทธิ์ใน repository) จะแสดงผลสำเร็จได้ต่อเมื่อ Gradle/Android SDK จากอินเทอร์เน็ตพร้อมใช้งาน

## ดูภาพเปรียบเทียบ

เปิด `PREVIEW_COMPARISON.html` ด้วยเบราว์เซอร์บนคอมพิวเตอร์หรือโทรศัพท์ เพื่อดูหน้าตาจำลองและแตะเปลี่ยนแท็บของ Native Preview ได้ หน้า HTML นี้เป็นภาพแนวทางเท่านั้น ไม่ใช่ตัว APK หรือภาพ Screenshot จาก Emulator
