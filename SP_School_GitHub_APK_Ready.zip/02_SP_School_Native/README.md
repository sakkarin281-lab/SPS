# S.P. School — Native Android

หน้าจอแอปที่เขียนด้วย Java Android Views และข้อมูลออฟไลน์บางส่วน

- ต้นแบบ ไม่ใช่แอปทางการของโรงเรียน
- Android Gradle Plugin 8.7.3; Gradle 8.9; SDK 35; minSdk 24; Java 17+
- แหล่งข้อมูล https://sp-school-v5.vercel.app/ (ตรวจสอบ 21 พ.ย. 2569)

## สร้าง APK

หากยังไม่มี `gradle/wrapper/gradle-wrapper.jar` ให้รัน `./gradlew wrapper --gradle-version 8.9` หรือ Windows `gradlew.bat wrapper --gradle-version 8.9` ครั้งแรก (ต้องเชื่อมต่ออินเทอร์เน็ต) เพื่อให้ Gradle สร้าง Official Wrapper ให้ก่อน

จากนั้นเปิดโฟลเดอร์นี้ด้วย Android Studio แล้วสั่ง Build APK หรือรัน `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`)

ตำแหน่งไฟล์ที่ได้: `app/build/outputs/apk/debug/app-debug.apk`

หมายเหตุ: ยังไม่มี APK แนบ เพราะเครื่องจัดทำไม่มี Android SDK/Gradle ที่ใช้คอมไพล์จริง
