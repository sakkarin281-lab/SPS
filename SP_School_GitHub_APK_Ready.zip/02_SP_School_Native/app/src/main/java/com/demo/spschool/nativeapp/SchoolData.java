package com.demo.spschool.nativeapp;

/**
 * Snapshot of publicly displayed S.P. School information, accessed 2026-11-21.
 * This is not an API and does not update automatically. Verify new fees with school.
 * Source: https://sp-school-v5.vercel.app/
 */
public final class SchoolData {
    private SchoolData() { }
    public static final String WEBSITE = "https://sp-school-v5.vercel.app/";
    public static final String SCHOOL = "โรงเรียนสุตะบำรุงพิทยาคาร";
    public static final String ADDRESS = "157 ถ.ระเบียบกิจอนุสรณ์ ต.บางคล้า อ.บางคล้า จ.ฉะเชิงเทรา";
    public static final String ADMISSIONS_PHONE = "081-561-1789";
    public static final String OFFICE_PHONE = "038-541-270";
    public static final String FINANCE_PHONE = "096-854-6142";
    public static final String VERIFIED_DATE = "21 พฤศจิกายน 2569";

    public static final class Program {
        public final String code, name, levels, summary, details;
        Program(String code, String name, String levels, String summary, String details) {
            this.code=code; this.name=name; this.levels=levels;
            this.summary=summary; this.details=details;
        }
    }
    public static final Program[] PROGRAMS = {
        new Program("IP", "Integrated Program", "อนุบาล 1–3",
            "แนวนานาชาติ · ใช้ภาษาอังกฤษ 100%",
            "เรียนรู้แบบ Learning Journey และกิจกรรมบูรณาการ · เว็บไซต์ระบุว่าไม่มีการบ้าน"),
        new Program("MEP", "Mini English Program", "อนุบาล 1–3 และ ป.1–6",
            "ภาษาอังกฤษเข้มข้น · ครูต่างชาติทำงานคู่ครูไทย",
            "ประถมเรียนอังกฤษ คณิต และวิทย์กับครูต่างชาติราว 9 คาบต่อสัปดาห์ · มี I-DAY วันอังคาร"),
        new Program("REG", "โปรแกรมทั่วไป", "เตรียมอนุบาล – ป.6",
            "หลักสูตรฐานสมรรถนะ · เรียนรู้แบบบูรณาการ",
            "เรียนอังกฤษกับครูต่างชาติและภาษาจีนควบคู่กัน · ระดับ ม.1–3 เปิดหลักสูตรเดียวแยกต่างหาก"),
        new Program("M1-3", "มัธยมต้นหลักสูตรเดียว", "ม.1–ม.3",
            "อังกฤษ · จีน · ดนตรี · Coding · หุ่นยนต์",
            "เว็บไซต์ระบุว่ามีวิชาหุ่นยนต์เบื้องต้นโดยไม่มีค่าเรียนเพิ่ม และแนะแนวเรียนต่อ")
    };

    public static final class Fee {
        public final String level, reg, mep, ip;
        Fee(String level, String reg, String mep, String ip) {
            this.level=level; this.reg=reg; this.mep=mep; this.ip=ip;
        }
    }
    /** THB per semester based on the published 2569 tuition schedule. */
    public static final Fee[] FEES = {
        new Fee("เตรียมอนุบาล", "9,700", "—", "—"),
        new Fee("อนุบาล 1–3", "8,760–9,360", "15,560–16,160", "39,060"),
        new Fee("ประถม ป.1–3", "5,460", "13,260", "—"),
        new Fee("ประถม ป.4–6", "5,560", "13,360", "—"),
        new Fee("มัธยมต้น ม.1–3", "5,210", "—", "—")
    };

    public static final String[] QUIZ_QUESTIONS = {
        "สนใจเรียนระดับชั้นใด?",
        "อยากให้ภาษาอังกฤษเข้มข้นระดับไหน?",
        "เด็กคุ้นเคยกับการใช้ภาษาอังกฤษอย่างไร?",
        "ชอบการเรียนรู้แบบใด?",
        "สิ่งที่ครอบครัวให้ความสำคัญเป็นอันดับแรก?"
    };
    public static final String[][] QUIZ_CHOICES = {
        {"อนุบาล 1–3", "ประถม ป.1–6", "มัธยมต้น ม.1–3"},
        {"เข้มข้นมาก", "ปานกลาง", "พื้นฐานทั่วไป"},
        {"ใช้เป็นประจำ", "ใช้เป็นบางครั้ง", "กำลังเริ่มต้น"},
        {"กิจกรรมและการสำรวจ", "ภาษาและวิชาหลัก", "หลากหลายสมดุล"},
        {"การใช้ภาษาอังกฤษ", "ค่าใช้จ่าย", "การเติบโตแบบรอบด้าน"}
    };
}
