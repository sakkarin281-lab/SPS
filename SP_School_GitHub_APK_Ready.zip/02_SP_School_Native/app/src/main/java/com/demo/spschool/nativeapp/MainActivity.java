package com.demo.spschool.nativeapp;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

/**
 * Original native Android UI, independent of WebView and third-party libraries.
 * This demo keeps only bookmarked program codes, never student personal data.
 */
public final class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(27, 61, 105);
    private static final int SKY = Color.rgb(54, 138, 200);
    private static final int PINK = Color.rgb(230, 109, 159);
    private static final int INK = Color.rgb(31, 48, 78);
    private static final int MUTED = Color.rgb(111, 126, 149);
    private static final int BG = Color.rgb(247, 249, 253);
    private static final int SOFT_BLUE = Color.rgb(232, 242, 251);
    private static final int SOFT_PINK = Color.rgb(255, 239, 246);

    private static final int HOME=0, PROGRAMS=1, FEES=2, MATCH=3, MORE=4;
    private static final String[] NAV_TEXT = {"หน้าแรก", "หลักสูตร", "ค่าเทอม", "จับคู่", "เพิ่มเติม"};
    private static final String[] NAV_ICONS = {"⌂", "▤", "฿", "◇", "☷"};

    private final TextView[] navButtons = new TextView[5];
    private LinearLayout screenBody;
    private SharedPreferences saved;
    private int currentTab = HOME;
    private int quizStep = 0;
    private final int[] quizAnswers = {-1, -1, -1, -1, -1};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        saved = getSharedPreferences("demo_favorites", MODE_PRIVATE);
        if (state != null) {
            currentTab = state.getInt("tab", HOME);
            quizStep = state.getInt("quizStep", 0);
            int[] restored = state.getIntArray("quizAnswers");
            if (restored != null && restored.length == quizAnswers.length) {
                System.arraycopy(restored, 0, quizAnswers, 0, restored.length);
            }
        }
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(Color.WHITE);
        buildShell();
        render();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("tab", currentTab);
        state.putInt("quizStep", quizStep);
        state.putIntArray("quizAnswers", quizAnswers);
        super.onSaveInstanceState(state);
    }

    private void buildShell() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout toolbar = row();
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(BLUE);
        toolbar.setPadding(dp(18), dp(11), dp(18), dp(11));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(68)));
        LinearLayout titleCol = column();
        toolbar.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        titleCol.addView(text("S.P. SCHOOL", 20, Color.WHITE, true));
        titleCol.addView(text("SUTA · Native Android Demo", 11, Color.rgb(203, 226, 243), false));
        TextView site = text("เว็บไซต์ ↗", 12, Color.WHITE, true);
        site.setGravity(Gravity.CENTER);
        site.setPadding(dp(12), dp(9), dp(12), dp(9));
        site.setBackground(shape(Color.rgb(47, 99, 151), 15, 0, 0));
        site.setContentDescription("เปิดเว็บไซต์ S.P. School ในเบราว์เซอร์");
        site.setOnClickListener(v -> openWebsite());
        toolbar.addView(site);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        screenBody = column();
        screenBody.setPadding(dp(16), dp(18), dp(16), dp(24));
        scroll.addView(screenBody, new ScrollView.LayoutParams(-1, -2));

        LinearLayout navigation = row();
        navigation.setPadding(dp(6), dp(7), dp(6), dp(4));
        navigation.setBackgroundColor(Color.WHITE);
        navigation.setElevation(dp(7));
        root.addView(navigation, new LinearLayout.LayoutParams(-1, dp(70)));
        for (int i=0; i<NAV_TEXT.length; i++) {
            final int index = i;
            LinearLayout group = column();
            group.setGravity(Gravity.CENTER);
            TextView symbol = text(NAV_ICONS[i], 24, MUTED, true);
            symbol.setGravity(Gravity.CENTER);
            group.addView(symbol);
            TextView label = text(NAV_TEXT[i], 11, MUTED, false);
            label.setGravity(Gravity.CENTER);
            group.addView(label);
            group.setContentDescription("แท็บ " + NAV_TEXT[i]);
            group.setOnClickListener(v -> { currentTab = index; render(); scroll.smoothScrollTo(0,0); });
            navigation.addView(group, new LinearLayout.LayoutParams(0, -1, 1));
            navButtons[i] = label;
            group.setTag(symbol);
        }
    }

    private void render() {
        screenBody.removeAllViews();
        for (int i=0; i<navButtons.length; i++) {
            boolean selected = currentTab==i;
            navButtons[i].setTextColor(selected ? BLUE : MUTED);
            navButtons[i].setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
            LinearLayout parent = (LinearLayout) navButtons[i].getParent();
            TextView symbol = (TextView) parent.getTag();
            symbol.setTextColor(selected ? PINK : MUTED);
        }
        switch (currentTab) {
            case HOME: renderHome(); break;
            case PROGRAMS: renderPrograms(); break;
            case FEES: renderFees(); break;
            case MATCH: renderMatching(); break;
            default: renderMore(); break;
        }
    }

    private void renderHome() {
        LinearLayout hero = column();
        hero.setPadding(dp(20), dp(23), dp(20), dp(23));
        hero.setBackground(gradient(BLUE, SKY, 22));
        screenBody.addView(hero, withBottom(0, 17));
        hero.addView(text("LEARN · LEAD · GROW", 11, Color.rgb(222, 242, 255), true));
        space(hero, 9);
        hero.addView(text("โรงเรียนสุตะบำรุง\nพิทยาคาร", 27, Color.WHITE, true));
        space(hero, 8);
        hero.addView(text("โรงเรียนที่นักเรียนเป็นเจ้าของการเรียนรู้", 14, Color.WHITE, false));
        space(hero, 18);
        LinearLayout chips = row();
        chips.addView(chip("เตรียมอนุบาล – ม.3", Color.WHITE, Color.rgb(36, 96, 154)));
        spaceHorizontal(chips, 7);
        chips.addView(chip("3 ภาษา", Color.WHITE, Color.rgb(36, 96, 154)));
        hero.addView(chips);

        notice("แอปต้นแบบ · ไม่ใช่แอปทางการของโรงเรียน", "ข้อมูลอ้างอิงจากหน้าเว็บเมื่อ " + SchoolData.VERIFIED_DATE + " และอาจมีการเปลี่ยนแปลง");
        section("สำรวจ S.P. School", "เลือกเมนูเพื่อดูข้อมูลที่สำคัญ");
        navTile("01", "โปรแกรมการเรียน", "IP, MEP, ทั่วไป และมัธยมต้น", PROGRAMS, SOFT_BLUE);
        navTile("02", "ตารางค่าเทอม 2569", "แสดงค่าเล่าเรียนต่อภาคเรียน", FEES, SOFT_PINK);
        navTile("03", "ลองจับคู่โปรแกรม", "ตอบแบบประเมินสาธิต 5 คำถาม", MATCH, SOFT_BLUE);

        section("ทำความรู้จักโรงเรียน", "ข้อมูลที่เว็บไซต์โรงเรียนเผยแพร่");
        LinearLayout facts = card();
        facts.addView(text("กว่า 70 ปีในบางคล้า", 18, INK, true));
        space(facts, 8);
        facts.addView(text("โรงเรียนเอกชนที่เปิดสอนตั้งแต่เตรียมอนุบาลถึงมัธยมศึกษาปีที่ 3 เน้นการเรียนรู้ผ่านการลงมือทำ และภาษาอังกฤษ–ภาษาจีน", 14, MUTED, false));
        space(facts, 12);
        facts.addView(chip("ปรัชญา: ประพฤติดี เรียนดี มีวินัย", BLUE, SOFT_BLUE));
        screenBody.addView(facts, withBottom(0, 12));

        button("เปิดเว็บไซต์ต้นทาง ↗", BLUE, Color.WHITE, this::openWebsite);
    }

    private void renderPrograms() {
        pageHeading("โปรแกรมการเรียน", "เลือกเส้นทางที่สนใจ · ข้อมูลจากหน้าเว็บไซต์");
        notice("หมายเหตุ", "รายละเอียดและการรับสมัครอาจเปลี่ยนตามปีการศึกษา โปรดยืนยันกับฝ่ายรับสมัคร");
        for (SchoolData.Program p : SchoolData.PROGRAMS) {
            LinearLayout card = card();
            LinearLayout head = row();
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView code = chip(p.code, Color.WHITE, p.code.equals("IP") ? PINK : SKY);
            head.addView(code);
            spaceHorizontal(head, 9);
            LinearLayout titles = column();
            titles.addView(text(p.name, 17, INK, true));
            titles.addView(text(p.levels, 12, MUTED, false));
            head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
            boolean chosen = saved.getBoolean("fav_" + p.code, false);
            TextView favorite = text(chosen ? "★" : "☆", 28, chosen ? PINK : MUTED, false);
            favorite.setPadding(dp(10), dp(5), dp(6), dp(5));
            favorite.setContentDescription(chosen ? "นำ " + p.name + " ออกจากรายการที่สนใจ" : "บันทึก " + p.name + " ที่สนใจ");
            favorite.setOnClickListener(v -> {
                saved.edit().putBoolean("fav_" + p.code, !chosen).apply(); render();
            });
            head.addView(favorite);
            card.addView(head);
            space(card, 12);
            card.addView(text(p.summary, 15, BLUE, true));
            space(card, 6);
            card.addView(text(p.details, 14, MUTED, false));
            screenBody.addView(card, withBottom(0, 12));
        }
        button("ดูรายละเอียดจากเว็บไซต์ ↗", BLUE, Color.WHITE, this::openWebsite);
    }

    private void renderFees() {
        pageHeading("ค่าเทอมปี 2569", "หน่วย: บาท / ภาคเรียน");
        notice("อ้างอิงระเบียบการ 2569", "ตัวเลขด้านล่างเป็นข้อมูลที่เว็บไซต์เผยแพร่ ไม่ใช่ใบแจ้งหนี้ และอาจเปลี่ยนแปลงได้");
        for (SchoolData.Fee fee : SchoolData.FEES) {
            LinearLayout tile = card();
            tile.addView(text(fee.level, 18, INK, true));
            space(tile, 11);
            feeLine(tile, "ทั่วไป / หลักสูตรเดียว", fee.reg, BLUE);
            if (!fee.mep.equals("—")) feeLine(tile, "MEP", fee.mep, SKY);
            if (!fee.ip.equals("—")) feeLine(tile, "IP", fee.ip, PINK);
            if (fee.level.equals("เตรียมอนุบาล")) {
                space(tile, 6);
                tile.addView(text("รายเดือน 2,425 บาท (ตามหน้าเว็บไซต์)", 12, MUTED, false));
            }
            screenBody.addView(tile, withBottom(0, 12));
        }
        LinearLayout help = card();
        help.addView(text("เรื่องการชำระเงิน", 17, INK, true));
        space(help, 7);
        help.addView(text("เว็บไซต์ระบุว่าชำระผ่าน SchoolBright และแบ่งชำระได้ 4 งวดต่อเทอม สอบถามฝ่ายการเงินเพื่อยืนยันเงื่อนไขล่าสุด", 14, MUTED, false));
        space(help, 10);
        inlineButton(help, "โทรฝ่ายการเงิน 096-854-6142", () -> dial(SchoolData.FINANCE_PHONE));
        screenBody.addView(help, withBottom(0, 12));
        button("ตรวจสอบค่าเทอมล่าสุดบนเว็บ ↗", BLUE, Color.WHITE, this::openWebsite);
    }

    private void feeLine(LinearLayout parent, String program, String value, int accent) {
        LinearLayout line = row();
        line.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(program, 14, MUTED, false);
        line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        line.addView(text(value + " ฿", 16, accent, true));
        parent.addView(line, withBottom(0, 9));
    }

    private void renderMatching() {
        pageHeading("School Matching · Demo", "แบบประเมินสาธิต 5 ข้อ ไม่ใช่เกณฑ์จริงของโรงเรียน");
        if (quizStep >= SchoolData.QUIZ_QUESTIONS.length) { renderResult(); return; }
        int count = SchoolData.QUIZ_QUESTIONS.length;
        TextView step = text("คำถาม " + (quizStep+1) + " จาก " + count, 13, PINK, true);
        screenBody.addView(step, withBottom(0, 9));
        LinearLayout progress = row();
        progress.setBackground(shape(Color.rgb(225, 233, 243), 5, 0, 0));
        for (int i=0; i<count; i++) {
            View segment = new View(this);
            segment.setBackground(shape(i<=quizStep ? SKY : Color.rgb(225, 233, 243), 5, 0, 0));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(7), 1);
            if (i>0) sp.leftMargin = dp(4);
            progress.addView(segment, sp);
        }
        screenBody.addView(progress, withBottom(0, 21));
        LinearLayout question = card();
        question.addView(text(SchoolData.QUIZ_QUESTIONS[quizStep], 21, INK, true));
        space(question, 16);
        for (int i=0; i<SchoolData.QUIZ_CHOICES[quizStep].length; i++) {
            final int choice = i;
            boolean selected = quizAnswers[quizStep] == i;
            TextView option = text((selected ? "●  " : "○  ") + SchoolData.QUIZ_CHOICES[quizStep][i], 16,
                    selected ? BLUE : INK, selected);
            option.setPadding(dp(16), dp(15), dp(16), dp(15));
            option.setBackground(shape(selected ? SOFT_BLUE : BG, 13, selected ? SKY : Color.rgb(227, 233, 242), 1));
            option.setContentDescription("คำตอบ " + SchoolData.QUIZ_CHOICES[quizStep][i]);
            option.setOnClickListener(v -> { quizAnswers[quizStep] = choice; render(); });
            question.addView(option, withBottom(0, 10));
        }
        screenBody.addView(question, withBottom(0, 16));
        if (quizAnswers[quizStep] != -1) {
            button(quizStep == count-1 ? "ดูผลเบื้องต้น →" : "ถัดไป →", BLUE, Color.WHITE,
                    () -> { quizStep++; render(); });
        }
        if (quizStep > 0) {
            button("← ย้อนกลับ", Color.WHITE, BLUE, () -> { quizStep--; render(); });
        }
        space(screenBody, 10);
        screenBody.addView(text("หมายเหตุ: แบบทดสอบนี้สร้างขึ้นเพื่อสาธิต UI เท่านั้น ไม่ได้คัดลอก 10 คำถามหรือการคำนวณจากเว็บไซต์", 12, MUTED, false));
    }

    private String resultLabel() {
        int level = quizAnswers[0];
        if (level == 2) return "มัธยมต้น (หลักสูตรเดียว)";
        boolean strongEnglish = quizAnswers[1] == 0 || quizAnswers[4] == 0;
        if (level == 0 && strongEnglish && quizAnswers[2] == 0) return "IP · Integrated Program";
        if (strongEnglish && quizAnswers[4] != 1) return "MEP · Mini English Program";
        return "โปรแกรมทั่วไป (REG)";
    }
    private String resultExplanation() {
        if (quizAnswers[0] == 2) return "เว็บไซต์ระบุว่าระดับ ม.1–3 มีหลักสูตรเดียว ไม่แบ่ง IP/MEP";
        if (resultLabel().startsWith("IP")) return "ตัวเลือกแสดงความสนใจภาษาอังกฤษเข้มข้นมาก และเด็กคุ้นเคยกับภาษาอังกฤษอยู่แล้ว";
        if (resultLabel().startsWith("MEP")) return "ตัวเลือกแสดงความสนใจภาษาอังกฤษเข้มข้น โดยยังเรียนวิชาหลักร่วมกับครูไทย";
        return "ตัวเลือกให้น้ำหนักกับความสมดุลและค่าใช้จ่าย จึงแสดงโปรแกรมทั่วไปเป็นจุดเริ่มต้น";
    }
    private String resultText() {
        return "ผลประเมินสาธิต S.P. School\nแนวทางเบื้องต้น: " + resultLabel() +
                "\n" + resultExplanation() + "\n(เป็นต้นแบบ ไม่ใช่คำแนะนำหรือผล Matching ทางการ)\n" + SchoolData.WEBSITE;
    }
    private void renderResult() {
        LinearLayout box = card();
        box.setBackground(shape(SOFT_BLUE, 21, 0, 0));
        box.addView(text("ผลประเมินเบื้องต้น", 14, SKY, true));
        space(box, 12);
        box.addView(text(resultLabel(), 24, BLUE, true));
        space(box, 10);
        box.addView(text(resultExplanation(), 15, INK, false));
        space(box, 15);
        box.addView(text("นี่เป็นเพียงตัวอย่างการจับคู่สำหรับทดสอบหน้าจอ ไม่ใช่ผลจาก School Matching ทางการ", 13, MUTED, false));
        screenBody.addView(box, withBottom(0, 14));
        button("คัดลอกผล", BLUE, Color.WHITE, () -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("S.P. Demo result", resultText()));
            Toast.makeText(this, "คัดลอกผลเรียบร้อย", Toast.LENGTH_SHORT).show();
        });
        button("แชร์ผล", SOFT_BLUE, BLUE, () -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, resultText());
            startActivity(Intent.createChooser(share, "แชร์ผลประเมินสาธิต"));
        });
        button("ทำแบบประเมินใหม่", Color.WHITE, BLUE, () -> {
            quizStep=0; Arrays.fill(quizAnswers, -1); render();
        });
        button("ทำ School Matching จริงบนเว็บ ↗", BLUE, Color.WHITE, this::openWebsite);
    }

    private void renderMore() {
        pageHeading("ข้อมูลเพิ่มเติม", "ข้อมูลสำหรับผู้ปกครองและช่องทางติดต่อ");
        section("สำหรับผู้ปกครอง", "ข้อมูลอ้างอิงจากคู่มือปีการศึกษา 2569 บนเว็บไซต์");
        LinearLayout parents = card();
        parents.addView(text("ปฏิทินการศึกษา", 18, INK, true));
        space(parents, 7);
        parents.addView(text("ภาคเรียน 1: 18 พ.ค. – 9 ต.ค. 2569", 14, MUTED, false));
        parents.addView(text("ภาคเรียน 2: 2 พ.ย. 2569 – 5 มี.ค. 2570", 14, MUTED, false));
        space(parents, 12);
        parents.addView(text("เวลาโดยย่อ", 18, INK, true));
        space(parents, 7);
        parents.addView(text("มาโรงเรียนได้ตั้งแต่ 07.00 น. · เริ่มนับว่าสายหลัง 08.00 น. · รับนักเรียน 15.30 น.", 14, MUTED, false));
        space(parents, 8);
        parents.addView(text("วันและเวลาอาจมีการเปลี่ยนแปลง ให้ตรวจสอบประกาศผ่าน SchoolBright", 12, PINK, false));
        screenBody.addView(parents, withBottom(0, 11));

        section("โปรแกรมที่บันทึกไว้", "แตะ ★ ในหน้าหลักสูตรเพื่อบันทึกความสนใจ");
        LinearLayout favorites = card();
        int count=0;
        for (SchoolData.Program p : SchoolData.PROGRAMS) {
            if (saved.getBoolean("fav_" + p.code, false)) {
                favorites.addView(text("★  " + p.code + " · " + p.name, 14, INK, true), withBottom(0, 9));
                count++;
            }
        }
        if (count==0) favorites.addView(text("ยังไม่มีโปรแกรมที่บันทึกไว้", 14, MUTED, false));
        screenBody.addView(favorites, withBottom(0, 12));

        section("ติดต่อโรงเรียน", "ติดต่อฝ่ายรับสมัครเพื่อยืนยันข้อมูลล่าสุด");
        LinearLayout contact = card();
        contact.addView(text(SchoolData.ADDRESS, 14, INK, false));
        space(contact, 9);
        contact.addView(text("จันทร์–ศุกร์ 08.00–16.00 น. (นัดเยี่ยมชมล่วงหน้า)", 13, MUTED, false));
        space(contact, 15);
        inlineButton(contact, "ฝ่ายรับสมัคร 081-561-1789", () -> dial(SchoolData.ADMISSIONS_PHONE));
        space(contact, 8);
        inlineButton(contact, "สำนักงาน 038-541-270", () -> dial(SchoolData.OFFICE_PHONE));
        space(contact, 8);
        inlineButton(contact, "เปิดเส้นทางบนแผนที่ ↗", this::openMap);
        screenBody.addView(contact, withBottom(0, 12));

        section("คำถามที่พบบ่อย", "ตัวอย่างคำตอบจากข้อมูลเผยแพร่");
        faq("เปิดสอนถึงระดับใด?", "ตั้งแต่เตรียมอนุบาล (เริ่ม 1 ขวบ 8 เดือนตามหน้าเว็บไซต์) ถึงมัธยมต้น ม.3");
        faq("มีโปรแกรมอะไรให้เลือก?", "อนุบาลมี IP, MEP และโปรแกรมทั่วไป · ประถมมี MEP และทั่วไป · มัธยมต้นมีหลักสูตรเดียว");
        faq("จะนัดเยี่ยมชมอย่างไร?", "ติดต่อฝ่ายรับสมัคร 081-561-1789 เพื่อยืนยันวันและเวลาที่สะดวก");
        button("ดู FAQ และ Suta AI บนเว็บ ↗", BLUE, Color.WHITE, this::openWebsite);
        space(screenBody, 14);
        screenBody.addView(text("ต้นแบบที่พัฒนาแยกจากเว็บไซต์ ไม่ได้เชื่อมระบบสมาชิก, SchoolBright, CRM หรือ AI ของโรงเรียน", 12, MUTED, false));
    }

    private void faq(String question, String answer) {
        LinearLayout c = card();
        c.addView(text(question, 15, INK, true));
        space(c, 7);
        c.addView(text(answer, 13, MUTED, false));
        screenBody.addView(c, withBottom(0, 10));
    }

    private void openWebsite() { openUri(Uri.parse(SchoolData.WEBSITE)); }
    private void dial(String phone) { openUri(Uri.parse("tel:" + phone.replace("-", ""))); }
    private void openMap() { openUri(Uri.parse("geo:0,0?q=" + Uri.encode(SchoolData.ADDRESS))); }
    private void openUri(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception e) { Toast.makeText(this, "ไม่พบแอปสำหรับเปิดลิงก์", Toast.LENGTH_SHORT).show(); }
    }

    private void pageHeading(String title, String subtitle) {
        screenBody.addView(text(title, 25, INK, true), withBottom(0, 5));
        screenBody.addView(text(subtitle, 13, MUTED, false), withBottom(0, 17));
    }
    private void section(String title, String subtitle) {
        screenBody.addView(text(title, 19, INK, true), withBottom(0, 4));
        screenBody.addView(text(subtitle, 12, MUTED, false), withBottom(0, 12));
    }
    private void notice(String title, String message) {
        LinearLayout box = column();
        box.setPadding(dp(15), dp(13), dp(15), dp(13));
        box.setBackground(shape(SOFT_PINK, 14, 0, 0));
        box.addView(text(title, 13, Color.rgb(133, 60, 92), true));
        space(box, 4);
        box.addView(text(message, 12, Color.rgb(138, 87, 107), false));
        screenBody.addView(box, withBottom(0, 17));
    }
    private void navTile(String number, String title, String description, int tab, int color) {
        LinearLayout tile = row();
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(15), dp(16), dp(14), dp(16));
        tile.setBackground(shape(Color.WHITE, 17, Color.rgb(230, 235, 244), 1));
        tile.setElevation(dp(1));
        TextView tileIcon = text(number, 17, BLUE, true);
        tileIcon.setGravity(Gravity.CENTER);
        tileIcon.setBackground(shape(color, 12, 0, 0));
        tile.addView(tileIcon, new LinearLayout.LayoutParams(dp(47), dp(47)));
        spaceHorizontal(tile, 12);
        LinearLayout copy = column();
        copy.addView(text(title, 16, INK, true));
        space(copy, 2);
        copy.addView(text(description, 12, MUTED, false));
        tile.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        tile.addView(text("›", 26, SKY, true));
        tile.setOnClickListener(v -> { currentTab = tab; render(); });
        screenBody.addView(tile, withBottom(0, 10));
    }
    private void button(String label, int bg, int fg, Runnable action) {
        TextView btn = text(label, 15, fg, true);
        btn.setGravity(Gravity.CENTER);
        btn.setMinHeight(dp(50));
        btn.setPadding(dp(14), dp(14), dp(14), dp(14));
        btn.setBackground(shape(bg, 15, bg==Color.WHITE ? Color.rgb(215, 226, 239) : 0, bg==Color.WHITE ? 1 : 0));
        btn.setOnClickListener(v -> action.run());
        btn.setContentDescription(label);
        screenBody.addView(btn, withBottom(0, 9));
    }
    private void inlineButton(LinearLayout parent, String label, Runnable action) {
        TextView btn = text(label + "   ›", 14, BLUE, true);
        btn.setGravity(Gravity.CENTER_VERTICAL);
        btn.setPadding(dp(13), dp(13), dp(13), dp(13));
        btn.setBackground(shape(SOFT_BLUE, 10, 0, 0));
        btn.setOnClickListener(v -> action.run());
        parent.addView(btn);
    }
    private LinearLayout card() {
        LinearLayout c = column();
        c.setPadding(dp(17), dp(17), dp(17), dp(17));
        c.setBackground(shape(Color.WHITE, 19, Color.rgb(230, 235, 244), 1));
        c.setElevation(dp(1));
        return c;
    }
    private TextView chip(String content, int foreground, int background) {
        TextView v = text(content, 12, foreground, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(7), dp(10), dp(7));
        v.setBackground(shape(background, 20, 0, 0));
        return v;
    }
    private GradientDrawable shape(int color, float radius, int stroke, float strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), stroke);
        return drawable;
    }
    private GradientDrawable gradient(int colorStart, int colorEnd, float radius) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{colorStart, colorEnd});
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        t.setLineSpacing(dp(2), 1.0f);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private LinearLayout.LayoutParams withBottom(int topDp, int bottomDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(topDp); p.bottomMargin = dp(bottomDp);
        return p;
    }
    private void space(LinearLayout p, float dp) { p.addView(new View(this), new LinearLayout.LayoutParams(1, dp(dp))); }
    private void spaceHorizontal(LinearLayout p, float dp) { p.addView(new View(this), new LinearLayout.LayoutParams(dp(dp), 1)); }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
}
