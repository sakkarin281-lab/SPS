import com.demo.spschool.nativeapp.SchoolData;

/** Run without Android SDK to validate static Native demo data. */
public class SchoolDataCheck {
    public static void main(String[] args) {
        ensure(SchoolData.PROGRAMS.length == 4, "Four visible programs");
        ensure(SchoolData.FEES.length == 5, "Five tuition rows");
        ensure(SchoolData.QUIZ_QUESTIONS.length == 5, "Five demo questions");
        ensure(SchoolData.QUIZ_CHOICES.length == SchoolData.QUIZ_QUESTIONS.length, "Questions/options aligned");
        for (String[] choices : SchoolData.QUIZ_CHOICES) ensure(choices.length == 3, "Three options per question");
        ensure(SchoolData.FEES[1].ip.equals("39,060"), "2569 IP kindergarten fee");
        ensure(SchoolData.FEES[4].reg.equals("5,210"), "2569 secondary fee");
        ensure(SchoolData.WEBSITE.startsWith("https://"), "Source uses HTTPS");
        System.out.println("PASS: school data, fees, and demo questions validated");
    }
    private static void ensure(boolean okay, String message) {
        if (!okay) throw new AssertionError(message);
    }
}
