# สร้าง APK S.P. School ผ่าน GitHub Actions

ไฟล์นี้เป็นคู่มือใช้ GitHub สร้าง APK โดยไม่ต้องลง Android Studio ในเครื่อง

## ขั้นตอน
1. เข้าบัญชี GitHub แล้วไปที่ https://github.com/new
2. สร้าง Repository ใหม่ชื่อ `SP-School-Android` และเลือก **Private** (ไม่ต้องนำไปใส่ Repository Parin)
3. ดาวน์โหลด `SP_School_GitHub_APK_Ready.zip` แล้วแตกไฟล์
4. ที่หน้า Repository เลือก **Add file → Upload files** จากนั้นอัปโหลด **ไฟล์และโฟลเดอร์ด้านใน ZIP** ทั้งหมด ไม่ใช่ไฟล์ ZIP ทั้งก้อน ได้แก่ `.github/`, `01_SP_School_WebView/`, `02_SP_School_Native/` และไฟล์คู่มือ
5. กด **Commit changes** ไปที่ Branch `main` (ถ้า Repository ยังไม่มีไฟล์ ให้ GitHub สร้าง Branch `main` ด้วยการ Commit แรก)
6. เปิดแท็บ **Actions → Build S.P. School Android APKs** (อาจต้องเปิดใช้งาน GitHub Actions)
7. การ Commit ไป `main` จะเรียก Build อัตโนมัติ หรือกด **Run workflow → Run workflow**
8. เมื่อ Job **Build WebView APK** และ **Build Native APK** แสดงสีเขียว ให้เปิดหน้า Run แล้วดาวน์โหลดไฟล์ ZIP ในส่วน **Artifacts**
9. แตก ZIP ของ Artifact จะพบ `app-debug.apk` จากนั้นเปลี่ยนชื่อเป็น `SP-School-WebView.apk` หรือ `SP-School-Native.apk` ได้ตามประเภท แล้วนำไปติดตั้งบน Android

**สำคัญ:** ต้องมี `.github/workflows/build-apks.yml` ใน Repository ถ้าอัปโหลดโฟลเดอร์ซ่อน `.github` ไม่ได้ ให้สร้างไฟล์นี้ด้วยเมนู **Add file → Create new file** และวางข้อความจากไฟล์ต้นแบบ

## ข้อมูลการ Build
- GitHub Actions ใช้ Java 17, Android SDK 35, Gradle 8.9 และ Android Gradle Plugin 8.7.3
- สร้างผ่าน `assembleDebug` แยก 2 โปรเจกต์ โดยจะมี Artifacts ชื่อ `SP-School-WebView-debug-APK` และ `SP-School-Native-debug-APK`
- APK เป็น Debug-signed ใช้ทดสอบเท่านั้น; ไม่ใช่ Release สำหรับ Play Store
- APK สร้างใหม่จากคนละ Runner อาจมีลายเซ็น Debug แตกต่างจากเดิม ถ้าติดตั้งทับไม่ได้ อาจต้องถอนแอปทดลองเก่า (ข้อมูลในแอปเดิมอาจหาย)
- Native เป็นต้นแบบจากข้อมูลสาธารณะ ไม่ใช่ระบบทางการของโรงเรียน
- ยังไม่ได้ทดสอบคอมไพล์บน GitHub จริงจนกว่าจะอัปโหลดและสั่งรัน Workflow

**ถ้า Build ล้มเหลว:** เปิด Actions → Run → Job ที่ขึ้นสีแดง แล้วคัดลอกข้อความ Error มาให้ตรวจแก้ได้
